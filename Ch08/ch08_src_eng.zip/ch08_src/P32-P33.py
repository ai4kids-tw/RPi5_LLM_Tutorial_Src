# P.32 -> P.33 [Python]
from flask import Flask, request, jsonify, send_from_directory
import os
import whisper

app = Flask(__name__)
model = whisper.load_model("tiny")

@app.route("/favicon.ico")
def favicon():
    return send_from_directory(os.path.join(app.root_path, 'static'),
                               'favicon.ico', mimetype='image/vnd.microsoft.icon')
@app.route("/", methods=["GET"])
def home():
    return "Welcome to the Transcription API! Use the /transcribe endpoint to transcribe audio files."

@app.route("/transcribe", methods=["POST"])
def transcribe():
    if "audio" not in request.files:
        return jsonify({"error": "No audio file provided"}), 400
    audio_file = request.files["audio"]
    # Check if the file is of a valid type (audio)
    if not audio_file.filename.endswith(('.mp3', '.wav', '.flac', '.m4a')):
        return jsonify({"error": "Invalid file format. Only audio files are allowed."}), 400
    result = model.transcribe(audio_file)
    return jsonify({"text": result["text"]})

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=False)



