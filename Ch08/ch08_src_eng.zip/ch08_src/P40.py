# P.40 [Python]
import whisper
import pyaudio
import numpy as np
model = whisper.load_model("tiny")
p = pyaudio.PyAudio()
stream = p.open(format=pyaudio.paInt16, channels=1, rate=16000, input=True, frames_per_buffer=4096)
print("Listening…")
while True:
  audio_data = stream.read(4096)
  audio_np = np.frombuffer(audio_data, dtype=np.int16).astype(np.float32) / 32768.0
  result = model.transcribe(audio_np)
  print(result["text"])
