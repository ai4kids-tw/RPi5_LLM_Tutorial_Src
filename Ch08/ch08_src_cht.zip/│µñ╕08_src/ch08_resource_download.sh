#! /usr/bin/env bash
##
##  Shell scipt to download needed files for ch08. 
##
##  By RungBa
##  Created: 2025-08-27
##  Revised: 2025-08-28
##
#
logFile=`basename $0 | cut -d. -f1`.log

## Show help
if [ -z "$1" ] || [ "$1" == "-h" ]; then
   echo 
   echo "This shell scipt is meant for downloading the resource files that is needed for LLM tutorial."
   echo 
   exit 1
fi


## *************************************************
## Block for Function define
## *************************************************
## Function for checking specific directory
FolderCheck(){
   local FolderName=$1
   
   #FolderName="~/$FolderName"
   echo "Checking Folder: $FolderName ..."
  
   ## Make sure the backup directory is existed
   if [ ! -d "$FolderName" ]; then
      mkdir -p "$FolderName" 2>&1 | tee -a $logFile
      printf "  -- Folder $FolderName is created!\n"  2>&1 | tee -a $logFile
   else
      echo "  -- The folder $FolderName already exists!" | tee -a $logFile
   fi
}

## Check folder ~/whisper
FolderCheck "~/whisper"
## download sample-1.mp3
printf "  -- Downloading sample-1.mp3 ... \n"  2>&1 | tee -a $logFile
wget -O ~/whisper/sample-1.mp3 https://github.com/ai4kids-tw/RPi5_LLM_Tutorial_Src/raw/refs/heads/main/Ch08/sample-1.mp3 

## Check folder ~/whisper
FolderCheck "~/whisper"
# download sample-ch.wav
printf "  -- Downloading sample-ch.wav ... \n"  2>&1 | tee -a $logFile
wget -O ~/whisper/sample-ch.wav https://github.com/ai4kids-tw/RPi5_LLM_Tutorial_Src/raw/refs/heads/main/Ch08/sample-ch.wav

# download sample-ch.wav
printf "  -- Downloading sample-ch-1.wav ... \n"  2>&1 | tee -a $logFile
wget -O ~/whisper/sample-ch-1.wav https://github.com/ai4kids-tw/RPi5_LLM_Tutorial_Src/raw/refs/heads/main/Ch08/sample-ch-1.wav

# download sample-ch.wav
printf "  -- Downloading audio.mp3 ... \n"  2>&1 | tee -a $logFile
wget -O ~/whisper/audio.mp3 https://github.com/ai4kids-tw/RPi5_LLM_Tutorial_Src/raw/refs/heads/main/Ch08/audio.mp3

