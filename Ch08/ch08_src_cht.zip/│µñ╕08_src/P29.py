# P.29 [Python]
import whisper

model = whisper.load_model("tiny") # Use "base" for better accuracy
result = model.transcribe("audio.mp3")
print(result["text"])